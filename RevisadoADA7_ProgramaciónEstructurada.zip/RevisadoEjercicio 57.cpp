#include <stdio.h>
#include <stdlib.h>

/*ADA 7 - Ejercicio 57
Actividad: E.P.  que  lea  una  matriz  de  N  X  M  elementos  y  que  encuentre  e
imprima la posici�n de los elementos negativos.
Fecha: 13 de Marzo del 2019
*/

int f,c,i,j;//Contadores

//Proceso
int main() {
	
	
	printf("Introduzca la cantidad de filas. ");
	scanf ("%i",&f);//Se le pide al usuario que introduzca la cantidad de filas que tendr� la matriz
	printf("Introduzca la cantidad de columnas. ");
	scanf ("%i",&c);//Se le pide al usuario que introduzca la cantidad de columnas que tendr� la matriz
	
	int matriz[f][c];//Se inicializa la matriz con las dimensiones dadas por el usuario
	
	//Proceso para pedir los elementos de la matriz
	for(i=0;i<f;i++){//Proceso de las filas
		for(j=0;j<c;j++){//Proceso de las columnas
			printf("\nIntroduzca el elemento de la fila %i, columna %i. ",i+1,j+1);
			scanf("%i",&matriz[i][j]);//Se le pide al usuario los elementos de la matriz
		}
	}
	
	system("cls");
	
	//Proceso para obtener los elementos de la matriz que son negativos
	for(i=0;i<f;i++){//Proceso filas
		for(j=0;j<c;j++){//Proceso columnas
			
			if(matriz[i][j]<0){//Condicional para obtener los elementos negativos
				printf("El elemento de la fila %i columna %i es negativo.",i+1,j+1);
			}
			
		}
		printf("\n");//Se imprime un salto de linea
	}
	
	return 0;
}

/*El programa funciona correctamente. NO se validan las dimensiones de la matriz

Revis�: Ricardo Nicol�s Canul Ibarra

Equipo: SacaChispas

*/

