/*
Nombre Equipo: Picateclas
Autores:
Dur�n Matos Juan Jos�
Gonz�lez Bautista No� Alejandro
L�pez Madera Fernanda Jacqueline
Version: 1.0
Descripcion: Lee un vector de n elementos y calcula e imprime su producto.
Fecha de creacion: 2/mar/2019
*/

#include <stdio.h>

int main(int argc, char *argv[]) {
	
	int N; //Numero de elementos
	int pos = 0; //Contador y posicionador del elemento del vector
	float MUL; //Producto de los elementos del vector
	
	//ENTRADA
	/*Se define la variable N e ingresa el numero de elementos que contendra el 
	vector*/
	printf("Ingrese el n�mero de elementos que contendr� el vector: ");
	scanf("%d",&N);
	
	float V[N]; //Se define el vector de N numeros decimales
	
	//PROCESO
	/*Se leen c/u de los elementos del vector y se van multiplicando y guardando en
	la variable MUL*/
	printf("\nUsted a ingresado un vector de %d elementos", N);
	printf("\nIngrese los %d elementos\n",N);
	
	while(pos<N){
		pos++;
		printf("Elemento %d: ",pos);
		scanf("%f",&V[pos]);
		
		if(pos == 1){
			MUL = V[pos];
		}
		else{
			MUL *= V[pos];
		}
	}
	
	//SALIDA
	/*Imprime el producto*/
	printf("EL producto de todos elementos ingresados es de: %.2f", MUL);
	return 0;
}

