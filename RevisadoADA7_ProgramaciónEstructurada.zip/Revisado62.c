#include <stdio.h>
#define m 5
#define n 5
int main(int argc, char *argv[]) {
	int i=0,j=0;
	float matriz[n][m],s=0.0;
	
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			printf ("\nIngresa el valor de la fila %d, columna %d\n",i+1,j+1);
			scanf ("%f",&matriz[i][j]);
			
		}
		printf ("\n");
	}
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			printf ("%.1f\t",matriz[i][j]);
		}
		printf ("\n");
	}
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			if (i==j){
				s=s+matriz[i][j];
			}
		}
	}
	printf("Suma de la diagonal de la matriz: %.1f",s);
return 0;
}

/*El programa funciona correctamente. El c�digo NO est� documentado y NO tiene el encabezado.
Sugerencia: Separar un poco el c�digo para que sea m�s f�cil enterderlo.

Revis�: Ricardo Nicol�s Canul Ibarra

Equipo: SacaChispas

*/
