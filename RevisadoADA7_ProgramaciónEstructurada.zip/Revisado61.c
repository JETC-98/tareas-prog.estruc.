#include <stdio.h>
#define m 3
#define n 2
int main(int argc, char *argv[]) {
	int i=0,j=0,alumno[n];
	float matriz[n][m],pg=0.0,p=0.0,pa=0.0,pag=0.0;
	
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			printf ("\nIngresa el valor del alumno %d, parcial %d\n",i+1,j+1);
			scanf ("%f",&matriz[i][j]);
			p=p+matriz[i][j];
		}
		printf ("\n");
	}
	pg=p/(n*m);
	printf ("Promedio grupal: %.2f\n",pg);
	
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			pa=pa+matriz[i][j];
		}
		pag=pa/j;
		if (pag>pg){
		alumno[i]=i+1;}
		else{
			alumno[i]=0;
		}
		pa=0;
	}
	printf ("\nAlumnos con promedio mayor al promdio general se encuentran en las posciiones:\n");
	for (i=0;i<n;i++){
		if (alumno[i]>0){ 
		printf ("%d\n",alumno[i]);}
	}
	
	return 0;
}
	
/*El programa funciona correctamente. El c�digo NO est� documentado y NO tiene el encabezado.
Sugerencia: Separar un poco el c�digo para que sea m�s f�cil enterderlo.

Revis�: Ricardo Nicol�s Canul Ibarra

Equipo: SacaChispas

*/
	
	
	
	
